/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Truck extends Car {
    private double M_weight;
    private double weight;

    public Truck(double Gas,double Efficiency,double M_weight,double weight) {
        super(Gas, Efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        
        if (weight > M_weight)
            this.weight = M_weight;
        else
            this.weight = M_weight;
    }
    public void drive(double distance){
        if(weight < 1)
            if (getGas() - distance / getEfficiency() < 0) {
                System.out.println("You cannot drive too far, please add gas.");
            }
            else {
                setGas(getGas() - distance / getEfficiency() );
        }    
        else if (weight <= 10)
            if (getGas() - distance / getEfficiency() * 1.1 < 0) {
                System.out.println("You cannot drive too far, please add gas.");
                }
            else {
                setGas(getGas() - distance / getEfficiency() * 1.1);
            }    
            
        else if (weight <= 20)
        if (getGas() - distance / getEfficiency() * 1.2 < 0) {
            System.out.println("You cannot drive too far, please add gas.");
            }
        else {
            setGas(getGas() - distance / getEfficiency() * 1.2);
        }    
        
        else
        if (getGas() - distance / getEfficiency() * 1.3 < 0) {
            System.out.println("You cannot drive too far, please add gas.");
            }
        else {
            setGas(getGas() - distance / getEfficiency() * 1.3);
        }    
        
    
    }
}
