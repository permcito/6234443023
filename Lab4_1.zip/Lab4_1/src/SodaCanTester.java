
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class SodaCanTester {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        
        
        System.out.print("Enter height : ");
        double inHeight = in.nextDouble();
        
        System.out.print("Enter diameter : ");
        double inRadius = in.nextDouble();
  
        
        SodaCan enter = new SodaCan(inHeight,inRadius);
        System.out.println("Volume:"+enter.getVolume());  
        System.out.println("Surface area:" + enter.getSurfaceArea());
    }
    
}
