
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Purse {
    private ArrayList<String> Coins;
    
    public Purse(){
        Coins = new ArrayList<String>();
    }
    public void addCoin(String coinName){
        Coins.add(coinName);
    }
    public String toString(){
        return Coins.toString();
    }
    public ArrayList<String> reverse(){
        for(int i = 0; i < Coins.size()/2;i++){
            String Coin1 = Coins.get(i);
            String Coin2 = Coins.get(Coins.size()-1-i);
            Coins.set(i,Coin2);
            Coins.set(Coins.size()-1-i,Coin1);
        }
        return Coins;
    }
    public void transfer(Purse other){
        for (String c : this.Coins){
            other.Coins.add(c);
                   }
    this.Coins.clear();

    }
    public boolean sameCoins(Purse other){
        if (this.Coins.size() != other.Coins.size())
            return false;
                    
        return (this.Coins.containsAll(other.Coins) && (other.Coins.containsAll(this.Coins)));
            
      
    }
   public boolean sameContents(Purse other){
       boolean same = true;
       if(Coins.size() == other.Coins.size()){
           for (int i = 0; i < Coins.size(); i++){
               boolean removed = false;
               for (int j = 0; j < other.Coins.size() && !removed; j++){
                   if (Coins.get(i) == other.Coins.get(j)){
                       other.Coins.remove(j);
                       removed = true;
                   }
                   if (!removed)
                       same = false;
               }
           }
       }
       else
           same = false;
       return same;
    
   }

         
     }
        
