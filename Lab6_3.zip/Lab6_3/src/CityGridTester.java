/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class CityGridTester {
    public static void main(String args[]) {
        CityGrid city = new CityGrid(10);
        int countSteps = 0;
        int totalSteps = 0;
        int maxSteps = 0;
        
        for (int i = 0; i < 10000; i++) {
            for (int j = 0; j < 1000; j++) {
                city.walk();
                countSteps++;
                if (!(city.isInCity())) {
                    break;
                }
            }

            totalSteps = totalSteps + countSteps;
            if (maxSteps < countSteps) {
                maxSteps = countSteps;
            }
            countSteps = 0;
            city.reset();
        }
        
        System.out.println("Average number of steps that a person can take and is still in the city: " + totalSteps / 10000.0);
        System.out.println("Maximum number of steps that a person can take and is still in the city: " + maxSteps);
    }
}