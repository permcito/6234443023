/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;

/**
 *
 * @author usci
 */
import java.util.Random;
import java.awt.Rectangle;
public class IntersectionPrinter {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random generator = new Random();
        
        Rectangle r1 = new Rectangle(generator.nextInt(50+1),generator.nextInt(50+1),generator.nextInt(50+1),generator.nextInt(50+1));
        Rectangle r2 = new Rectangle(generator.nextInt(50+1),generator.nextInt(50+1),generator.nextInt(50+1),generator.nextInt(50+1));
        System.out.println(r1);
        System.out.println(r2);
        Rectangle r3 = r1.intersection(r2);
        System.out.println("Is the intersected rectangle empty?:"+r3.isEmpty());
        
    }
    
}
