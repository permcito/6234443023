/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class CNGBus extends Bus implements LiquidFuel {
    double range;
    int EmissionTier;
    
    public CNGBus(int capacity,double cost,double range,int EmissionTier){
        super(capacity,cost);
        this.range= range;
        this.EmissionTier = EmissionTier;
    }
    public double getAccel(){
        return 3.0;
    }
    public int getEmissionTier(){
        return EmissionTier;
    }
    
    public double getRange(){
        return range;
    }
}
