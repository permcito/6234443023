/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Hybrid extends Bus implements LiquidFuel,Electric{
    double voltage;
    double range;
    int EmissionTier;
    public Hybrid(int capacity,double cost,double voltage,double range,int EmissionTier){
        super(capacity,cost);
        
        if(voltage < LOW_VOLTAGE ){
            this.voltage = LOW_VOLTAGE;
        }
        else if(voltage >HIGH_VOLTAGE){
            this.voltage = HIGH_VOLTAGE;
    }
    this.range = range;
        this.EmissionTier = EmissionTier;
}
    public double getAccel(){
        return 4.0;
    }
   
    public int getEmissionTier(){
        return EmissionTier;
    }
   
    public double getRange(){
        return range;
    }
   
    public  double getVoltage(){
        return voltage;
    }
}

