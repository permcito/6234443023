/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class SodaCan {
    private double height;
    private double radius;
    
    public SodaCan(double Height, double Radius){
    height = Height;
    radius = Radius/2;
   
}

    public double getVolume(){
        double volume = Math.PI * height * (radius*radius);
        return volume;
    }
    public double getSurfaceArea(){
        double area = height*(2*Math.PI*radius) + 2*Math.PI*(radius*radius);
        return area;
    }
}
