public class StampMachine{
    private int Insert;
    public static final double firstClassStampPrice = 0.44;
    
    public StampMachine() {
        Insert = 0;
}
    public void insert(int dollars){
        Insert = dollars;
    }
    public int giveFirstClassStamps(){
        int amount = (int) ((int)  Insert / firstClassStampPrice);
        Insert = amount - Insert;
        return amount;
        
    }
    public int givePennyStamps(){
        double amountPenny = (double) (Insert % firstClassStampPrice);
        amountPenny = amountPenny * 100;
        return (int) amountPenny;
    }
}
