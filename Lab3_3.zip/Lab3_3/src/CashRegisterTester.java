/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class CashRegisterTester {
    public static void main(String[] args)
    {
        CashRegister cashRegister = new CashRegister(7);
        cashRegister.recordPurchase(50);
        cashRegister.recordPurchase(10);
        cashRegister.recordTaxablePurchase(20);
        cashRegister.enterPayment(100);
        System.out.println("Your change is " + cashRegister.giveChange());
        
    }
    
}
