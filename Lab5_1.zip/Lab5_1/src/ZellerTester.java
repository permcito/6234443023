
import java.util.Scanner;


public class ZellerTester {

    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
         System.out.print("Enter the year (e.g., 2012): ");             
          int year = input.nextInt();
        
         System.out.print("Enter month (1-12):");
          int month = input.nextInt();
         
         System.out.print("Enter day of the month (1-31):");
          int dayOfMonth = input.nextInt();
          Zeller ans = new Zeller();
          ans.getDayOfWeek(year, month, dayOfMonth);
          

        

}
}

