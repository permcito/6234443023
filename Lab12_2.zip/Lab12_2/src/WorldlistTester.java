
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class WorldlistTester {
     public static void main(String[] args){
       
        ArrayList<String> data = new ArrayList<>();
        try{
            Scanner in = new Scanner(new File("/Users/prutprommart/NetBeansProjects/Lab12_2/src/worldlist.txt"));
            String line;
            while (in.hasNextLine()){
                line = in.nextLine();
                data.add(line.trim());
            }
        }catch (IOException e){
            System.out.println(e);
        }
        System.out.print("Enter a sentence: ");
        String text = (new Scanner(System.in)).nextLine();
        Scanner t = new Scanner(text);
        System.out.println("Words not contained: ");
        boolean contained = false;
        while(t.hasNext()){
            String check = (t.next()).trim();
            if (!data.contains(check)){
                System.out.println(check);
                contained = true;
            }
        }
        if (!contained){
            System.out.println("N/A");
        }
       
    }
}
