/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class Letter {
    private String send;
    private String rec;
    private String text;
    
    public Letter(String from, String to)
    {
        send = from;
        rec = to;
        text = "";
    }
    public void addLine(String line)
    {
        text = text + line + "\n" ;
    }
    public String getText()
    {
        return "Dear" +" "+ rec +":"+ "\n"+ "\n" + text + "\n" + "Sincerely"+","+"\n" + "\n" + send; 
    }

   
}
