/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class PurseTester {
    public static void main(String[] args){
        Purse purse1 = new Purse();
        Purse purse2 = new Purse();
        
        
        purse1.addCoin("Quarter");
        purse1.addCoin("Dime");
        purse1.addCoin("Nickel");
        purse1.addCoin("Dime");
        
        
        purse2.addCoin("Quarter");
        purse2.addCoin("Dime");
        purse2.addCoin("Nickel");
        purse2.addCoin("Dime");
       
        
       //System.out.println(purse1.toString());   
        //System.out.println(purse1.reverse());
        //purse1.transfer(purse2);

  
        System.out.println(purse1.sameCoins(purse2));
        //System.out.println(purse1.sameContents(purse2));
        
    }
}
