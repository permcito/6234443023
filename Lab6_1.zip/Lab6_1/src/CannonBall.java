/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV; //ความเร็วตั้งต้น
    private double simS; //ระยะทางที่คำนวณได้จากวิธี simulation
    private double simT; //เวลาที่ใช้ในวิธี simulation
    public static final double g = 9.81;
    
    public CannonBall(double initV){
        this.initV = initV;
    }
    public void simulatedFlight(){
       double v = initV;
       double s = 0;
       double dt = 0.01;
       double ds = 0;
       double t = 0;
       double time = 0;
       double timeCount = 0;
       while (v>0){
           time = time + dt;
           ds = v * dt;
           s = s + ds;
           v = v - g*dt;
           timeCount++;
           if (timeCount == 100.00){
               t = t + 1;
               System.out.println("Distance on " + t + " sec: " + s);
               timeCount = 0;
           }
           
       }
       System.out.printf("Final distance: %.2f Total time: %.2f%n ",s,time);
       simS = s;
       simT = time;
    }
    public double calculusFlight(double t){
       return -0.5*g*Math.pow(t, 2) + initV * t;
    }
    public double getSimulatedTime(){
        return Math.sqrt((2*simS)/g);
    }
    public double getSimulatedDistance(){
        return simS * 2;
    }
}
