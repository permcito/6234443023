
public class Zeller{
    private int dayOfMonth; 
    private int month; 
    private int year;

 enum Day{
    SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),
    FRIDAY("Friday"), SATURDAY("Saturday");
    private final String day;
    Day(String day){
    this.day = day;
}

}
    public Day getDayOfWeek(int year,int month,int d){

            if (month == 1) 
            { 
                month = 13; 
                year--; 
            } 
            if (month == 2) 
            { 
                month = 14; 
                year--; 
            } 
            int q = d; 
            int m = month; 
            int k = year % 100; 
            int j = year / 100; 
            int h = q + 26*(m + 1) / 10 + k + k / 4 + j / 4 + 5 * j; 
            h = h % 7; 
            switch (h) 
            { 
                case 0 : System.out.print("Day of the week is "+ Day.SATURDAY.day);
                break; 
                case 1 : System.out.print("Day of the week is "+Day.SUNDAY.day); 
                break;  
                case 2 : System.out.print("Day of the week is  "+Day.MONDAY.day); 
                break; 
                case 3 : System.out.print("Day of the week is  "+Day.TUESDAY.day); 
                break; 
                case 4 : System.out.print("Day of the week is "+Day.WEDNESDAY.day); 
                break; 
                case 5 : System.out.print("Day of the week is "+Day.THURSDAY.day); 
                break; 
                case 6 : System.out.print("Day of the week is "+Day.FRIDAY.day); 
                break; 
            } 
        return null;
            

    } 
        
    }