package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num;
    private Button Send;
    private TextView result;
    public static String ans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num = (EditText)findViewById(R.id.editText);
        Send = (Button)findViewById(R.id.btnAdd);
        result = (TextView)findViewById(R.id.textView);

        Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int y = Integer.parseInt(num.getText().toString());
                int a = y % 19;
                int b = y / 100;
                int c = y % 100;
                int d = b/ 4;
                int e = b % 4;
                int g = ((8 * b) + 13) / 25;
                int h = ((19 * a) + b - d - g + 15) % 30;
                int j = c / 4 ;
                int k = c % 4;
                int m =  (a + 11 * h ) / 319 ;
                int r = ((2 * e) + (2 * j) - k - h + m + 32) % 7;
                int n = (h - m + r + 90) / 25;
                int p = (h - m + r + n + 19) % 32;

                if(n == 1) {
                    ans = "January";
                }
                if(n == 2) {
                    ans = "February";
                }
                if(n == 3) {
                    ans = "March";
                }
                if(n == 4) {
                    ans = "April";
                }
                if(n == 5) {
                    ans = "May";
                }
                if(n == 6) {
                    ans = "June";
                }
                if(n == 7) {
                    ans = "July";
                }
                if(n == 8) {
                    ans = "August";
                }
                if(n == 9) {
                    ans = "September";
                }
                if(n == 10) {
                    ans = "October";
                }
                if(n == 11) {
                    ans = "November";
                }
                if(n == 12) {
                    ans = "December";
                }

                result.setText("Your Easter day is : " + String.valueOf(ans)+String.valueOf(p));
            }
        });
    }
}
