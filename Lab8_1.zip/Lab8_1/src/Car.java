/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Car{
    private double gas;
    private double efficiency;

    public Car(double gas,double efficiency){
        this.gas = gas;
        this.efficiency = efficiency;
    }
    public void drive(double distance){
        if (gas - distance / efficiency < 0) {
            System.out.println("You cannot drive too far, please add gas.");
        }
        else {
            gas = gas - distance / efficiency;
        }   
    }
    public void setGas(double amount){
        gas = amount;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        gas += amount;
    }
}


