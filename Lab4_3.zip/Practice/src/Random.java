/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Random {
    public class void main(String[] args){
        for(int i = 1;, i <= 6; i++){
            for(int j = 1; j <= 1; j
                System.out.print(j);
    }
    for(int k = 6; k > i; k--){
        System.out.print("*");
    }
    System.out.println();    
    }


    
}
