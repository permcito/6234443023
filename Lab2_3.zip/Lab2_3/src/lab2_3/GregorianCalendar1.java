/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

/**
 *
 * @author usci
 */
import java.util.Calendar;
import java.util.GregorianCalendar;
public class GregorianCalendar1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        GregorianCalendar myBirthday = new GregorianCalendar(1990,Calendar.MARCH,12);
        GregorianCalendar toDay = new GregorianCalendar(2019,Calendar.JANUARY,8);
        
        
        
        toDay.add(Calendar.DAY_OF_MONTH, 100);
        int dayOfMonth2  = toDay.get(Calendar.DAY_OF_MONTH);
        int month2 = toDay.get(Calendar.MONTH)+1;
        int year2 = toDay.get(Calendar.YEAR);
        int weekday2 = toDay.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday2 + " "+ dayOfMonth2 + " "+ month2 + " " + year2);
        
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth  = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month = myBirthday.get(Calendar.MONTH)+1;
        int year = myBirthday.get(Calendar.YEAR);
        int weekday = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday + " "+ dayOfMonth + " "+ month + " " + year);
        
    }
    
}
