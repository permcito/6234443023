/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author usci
 */
import java.util.Scanner;
public class HollePrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner Str = new Scanner(System.in);
        System.out.println("Enter String :");
        
        String totalObj = Str.nextLine();
        String totalObj2 = totalObj.replace('o','%').replace('e','o').replace('%','e');

        
        System.out.println(totalObj2);
        
    }
    
}
