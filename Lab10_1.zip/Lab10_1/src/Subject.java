/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Subject implements Evaluation {

    private String subjName;
    private int[] score;

    public Subject(String name, int[] s) {
        subjName = name;
        score = s;
    }

    public double evaluate() {
        int sum = 0;
        for (int e : score) {
            sum = sum + e;
        }
        return sum;
    }

    public char grade(double score) {
        if (score >= 70) {

            return 'P';
        } else {
            return 'F';
        }

    }

    public String toString() {
        return subjName;
    }

}
