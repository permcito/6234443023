/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Secretary extends Employee implements Evaluation {
   
    private int typingSpeed;
    private int[] score;
    public Secretary(String name,int salary ,int[] score,int typingSpeed){
        super(name,salary);
        this.score = score;
        this.typingSpeed = typingSpeed;
        
    }
    public double evaluate(){
        int sum = 0;
        for(int e : score){
            sum = sum + e;
        }
        return sum;
    }
    public char grade(double score){
        if (score>=90){
            setSalary(18000);
            return 'P';
        }else{
            return 'F';
        }
    }
    
}
